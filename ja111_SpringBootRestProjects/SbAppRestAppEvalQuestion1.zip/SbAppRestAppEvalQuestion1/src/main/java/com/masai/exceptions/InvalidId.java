package com.masai.exceptions;

public class InvalidId extends RuntimeException{

	public InvalidId() {
		
	}
	public InvalidId(String mag) {
		
	}
	
}