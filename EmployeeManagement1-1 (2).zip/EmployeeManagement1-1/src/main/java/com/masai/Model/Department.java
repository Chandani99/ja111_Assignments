package com.masai.Model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity

public class Department {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer dId;
	private String dName;
	@OneToMany(cascade = CascadeType.ALL)
	@JsonIgnoreProperties("emp")
	private List<Employee> emp = new ArrayList<>();

	public Department(Integer dId, String dName, List<Employee> emp) {
		super();
		this.dId = dId;
		this.dName = dName;
		this.emp = emp;
	}

	public Department() {
		super();
	}

	public Integer getdId() {
		return dId;
	}

	public void setdId(Integer dId) {
		this.dId = dId;
	}

	public String getdName() {
		return dName;
	}

	public void setdName(String dName) {
		this.dName = dName;
	}

	public List<Employee> getEmp() {
		return emp;
	}

	public void setEmp(List<Employee> emp) {
		this.emp = emp;
	}

	@Override
	public String toString() {
		return "Department [dId=" + dId + ", dName=" + dName + ", emp=" + emp + "]";
	}

}
