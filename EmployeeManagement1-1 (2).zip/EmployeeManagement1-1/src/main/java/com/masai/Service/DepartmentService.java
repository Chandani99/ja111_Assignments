package com.masai.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.masai.Model.Department;
import com.masai.Model.Employee;
@Service
public interface DepartmentService {
	public Department addDepartment(Department dep);
    public List<Employee> getEmployeebyDId(Integer dId);
    public String getDepartmentNameByEmpId(Integer eId);
 
}
