package com.masai.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.masai.Model.Employee;
import com.masai.Reposatory.EmployeeDao;

@Service

public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao eDao;

	@Override
	public Employee getEmployeeById(Integer eId) {
		Optional<Employee> employee = eDao.findById(eId);
		return employee.get();
	}

	@Override
	public List<Employee> getEmployeeByDId(Integer dId) {
		List<Employee> empAll = eDao.findAll();
		List<Employee> employeeInDepartment = new ArrayList<>();
		for (Employee emp : empAll) {
			if (emp.geteId() == dId) {
				employeeInDepartment.add(emp);
			}
		}
		// TODO Auto-generated method stub
		return employeeInDepartment;
	}

	@Override
	public List<Employee> getAllEmployee() {
		List<Employee> empAll = eDao.findAll();
		return empAll;
	}

//	@Override
//	public String updateEmployeeDetailById(Employee emp) {
////		eDao.save(emp);
//		return null;
//	}

	@Override
	public Employee addEmployee(Employee emp) {
		Employee emp1 = eDao.save(emp);

		return emp1;
	}

}
